
  # 3D Building Model Editor (Copy)

  This is a code bundle for 3D Building Model Editor (Copy). The original project is available at https://www.figma.com/design/durex9y0cCI4OzveDCnws1/3D-Building-Model-Editor--Copy-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  